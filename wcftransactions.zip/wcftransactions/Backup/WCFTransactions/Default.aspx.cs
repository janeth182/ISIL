﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Transactions;
namespace WCFTransactions
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                using (TransactionScope ts = new TransactionScope(TransactionScopeOption.Required))
                {
                    try
                    {
                        ServiceReference1.Service1Client obj = new ServiceReference1.Service1Client();
                        obj.UpdateData();
                        ServiceReference2.Service1Client obj1 = new ServiceReference2.Service1Client();
                        obj1.UpdateData();
                        ts.Complete();
                    }
                    catch (Exception ex)
                    {
                        ts.Dispose();
                    }
                }
            
           
        }
    }
}
